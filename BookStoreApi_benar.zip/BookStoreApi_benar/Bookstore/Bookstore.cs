public class BookStore
{
    public string? Title { get; set; }
    public bool IsDone { get; set; }
    public string? Id { get; set; }

    public string? BookName { get; set; } 

    public decimal? Price { get; set; } 

    public string? Category { get; set; } 

    public string? Author { get; set; } 
}